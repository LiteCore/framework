<?php

  class ref_database {

    private $_data = [];

    function __construct() {
    }

    public function &__get($name) {

      if (array_key_exists($name, $this->_data)) {
        return $this->_data[$name];
      }

      $this->_data[$name] = null;
      $this->_load($name);

      return $this->_data[$name];
    }

    public function &__isset($name) {
      return $this->__get($name);
    }

    public function __set($name, $value) {
      trigger_error('Setting data is prohibited ('.$name.')', E_USER_WARNING);
    }

    private function _load($field) {

      switch ($field) {

        case 'tables':

          $this->_data['tables'] = [];

          $tables_query = database::query(
            "show table status;"
          );

          while ($table = database::fetch($tables_query)) {
            $this->_data['tables'][] = [
              'name' => $table['Name'],
              'rows' => $table['Rows'],
              'engine' => $table['Engine'],
              'collation' => $table['Collation'],
              'comment' => $table['Comment'],
            ];
          }

          break;

        default:
          trigger_error('Unknown field data name ('. $field .')', E_USER_ERROR);
      }
    }
  }
