<?php

  class ref_database_table {

    private $_table_name;
    private $_data = [];

    function __construct($table_name) {

      if (preg_match('#[^a-zA-Z0-9_]#', $table_name)) {
        trigger_error('Invalid database table name ('. $table_name .')', E_USER_WARNING);
      }

      $this->_table_name = $table_name;
    }

    public function &__get($name) {

      if (array_key_exists($name, $this->_data)) {
        return $this->_data[$name];
      }

      $this->_data[$name] = null;
      $this->_load($name);

      return $this->_data[$name];
    }

    public function &__isset($name) {
      return $this->__get($name);
    }

    public function __set($name, $value) {
      trigger_error('Setting data is prohibited ('.$name.')', E_USER_WARNING);
    }

    private function _load($field) {

      switch ($field) {

        case 'columns':

          $this->_data['columns'] = [];

          $columns_query = database::query(
            "show full columns from `". database::input($this->_table_name) ."`;"
          );

          while ($column = database::fetch($columns_query)) {
            $this->_data['columns'][] = [
              'name' => $column['Field'],
              'type' => $column['Type'],
              'length' => preg_match('#\((.*?)\)#', $column['Type'], $matches) ? $matches[1] : '',
              'null' => preg_match('#^yes$#i', $column['Null']) ? true : false,
              'unsigned' => preg_match('#^unsigned$#i', $column['Type']) ? true : false,
              'zerofill' => preg_match('#^zerofill$#i', $column['Type']) ? true : false,
              'primary' => preg_match('#^pri$#i', $column['Key']) ? true : false,
              'key' => $column['Key'],
              'default' => $column['Default'],
              'auto_increment' => preg_match('#auto_increment#i', $column['Extra']) ? true : false,
              'collation' => $column['Collation'],
              'comment' => $column['Comment'],
            ];
          }

          break;

        case 'indexes':

          $this->_data['indexes'] = [];

          $index_query = database::query(
            "show index from `". database::input($this->_table_name) ."`;"
          );

          while ($index = database::fetch($index_query)) {
            if (!isset($this->_data['indexes'][$index['Key_name']])) {
              $this->_data['indexes'][$index['Key_name']] = [
                'name' => $index['Key_name'],
                'kind' => ($index['Key_name'] == 'PRIMARY') ? 'primary' : (!$index['Non_unique'] ? 'unique' : 'key'),
                'type' => $index['Index_type'],
                'columns' => [$index['Column_name']],
                'cardinality' => $index['Cardinality'],
                'comment' => $index['Index_comment'],
              ];
            } else {
              $this->_data['indexes'][$index['Key_name']]['columns'][] = $index['Column_name'];
            }
          }

          break;

        case 'primary_column':

          $this->_data['primary_column'] = null;

          foreach ($this->columns as $column) {
            if ($column['primary']) {
              $this->_data['primary_column'] = $column['name'];
              break;
            }
          }

          break;

        case 'rows':

          $this->_data['rows'] = [];

          $query = database::query(
            "select * from `". database::input($this->_table_name) ."`
            ;"
          );

          while ($row = database::fetch($query)) {
            $this->_data['rows'][] = $row;
          }

          break;

        default:
          trigger_error('Unknown field data name ('. $field .')', E_USER_ERROR);
      }
    }
  }
