<?php

  #[AllowDynamicProperties]
  abstract class abs_module {



  }