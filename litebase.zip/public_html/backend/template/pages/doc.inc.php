<style>
#main {
  --app-color: <?php echo $theme['color']; ?>;
}
#top-bar {
  border-bottom: 5px solid var(--app-color);
}
</style>

{{notices}}
{{content}}
