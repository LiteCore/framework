<?php

  return $widget_config = [
    'name' => language::translate('title_system', 'System'),
    'file' => 'system.inc.php',
    'priority' => 1,
  ];
