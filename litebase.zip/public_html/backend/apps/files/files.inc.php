<?php

  if (empty($_GET['path'])) $_GET['path'] = '/';

  $_GET['path'] = rtrim('/' . functions::file_resolve_path($_GET['path']), '/') . '/';
  if (!is_dir(FS_DIR_APP . $_GET['path']) || !preg_match('#^'. preg_quote(FS_DIR_APP, '#') .'#', FS_DIR_APP . $_GET['path'])) {
    die('Invalid path');
  }

  //breadcrumbs::add(language::translate('title_files', 'Files'), document::ilink(__APP__.'/files'));

  if (!empty($_GET['path'])) {
    $prefix = '';
    foreach (preg_split('#/#', $_GET['path'], -1, PREG_SPLIT_NO_EMPTY) as $part) {
      breadcrumbs::add($part, document::ilink(null, ['path' => $prefix .'/'. $part . '/']));
      $prefix .= '/' . $part;
    }
  }

  if (!empty($_POST['mkdir'])) {

    try {

      if (empty($_POST['directory'])) throw new Exception('No directory name provided');

      if (!preg_match('#^'. preg_quote(FS_DIR_APP, '#') .'#', FS_DIR_APP . rtrim($_GET['path'], '/') . '/' . basename($_POST['directory']))) {
        throw new Exception(language::translate('error_access_forbidden', 'Access forbiden'));
      }

      if (!mkdir(FS_DIR_APP . rtrim($_GET['path'], '/') . '/' . basename($_POST['directory']))) {
        throw new Exception('Could not create directory');
      }

      $_GET['path'] = rtrim($_GET['path'], '/') . '/' . basename($_POST['directory']);

      header('Location: ' . document::ilink());
      exit;

    } catch (Exception $e) {
      notices::add('errors', $e->getMessage());
    }
  }

  if (!empty($_POST['chmod'])) {

    try {

      if (empty($_POST['file'])) throw new Exception('No file to chmod');
      if (empty($_POST['chmod'])) throw new Exception('Missing chmod value');

      if (!preg_match('#^'. preg_quote(FS_DIR_APP, '#') .'#', FS_DIR_APP . rtrim($_GET['path'], '/') . '/' . basename($_POST['directory']))) {
        throw new Exception(language::translate('error_access_forbidden', 'Access forbiden'));
      }

      if (!chmod(FS_DIR_APP . rtrim($_GET['path'], '/') . '/' . basename($_POST['file']), $_POST['chmod'])) {
        throw new Exception('Could not chmod file');
      }

      notices::add('success', language::translate('success_changes_saved', 'Changes saved'));
      header('Location: ' . document::ilink());
      exit;

    } catch (Exception $e) {
      notices::add('errors', $e->getMessage());
    }
  }

  if (!empty($_POST['delete'])) {

    try {

      if (empty($_POST['folders']) && empty($_POST['files'])) throw new Exception('No files or folders selected');

      if (!empty($_POST['folders'])) {
        foreach ($_POST['folders'] as $folder) {
          functions::file_delete(FS_DIR_APP . trim($folder, '/'));
        }
      }

      if (!empty($_POST['files'])) {
        foreach ($_POST['files'] as $file) {
          functions::file_delete(FS_DIR_APP . trim($file, '/'));
        }
      }

      notices::add('success', language::translate('success_changes_saved', 'Changes saved'));
      header('Location: ' . document::ilink());
      exit;

    } catch (Exception $e) {
      notices::add('errors', $e->getMessage());
    }
  }

  if (!empty($_POST['upload'])) {

    try {

      if (empty($_FILES['files'])) throw new Exception('No files uploaded');
      if (empty($_POST['paths'])) throw new Exception('No paths defined for uploaded files');
      if (count($_POST['paths']) != count($_FILES['files']['tmp_name'])) throw new Exception('No paths defined for uploaded files');

      foreach (array_keys($_FILES['files']['tmp_name']) as $key) {
        $new_file = FS_DIR_APP . ltrim($_GET['path'], '/') . functions::file_strip_path($_POST['paths'][$key]);
        mkdir(dirname($new_file), 0777, true);
        move_uploaded_file($_FILES['files']['tmp_name'][$key], $new_file);
      }

      header('Location: ' . document::link());
      exit;

    } catch (Exception $e) {
      die($e->getMessage());
      notices::add('errors', $e->getMessage());
    }
  }

  $folders = [];
  $files = [];

  foreach (scandir(FS_DIR_APP . $_GET['path']) as $file) {

    if (in_array($file, ['.', '..'])) continue;

    if (is_dir(FS_DIR_APP . $_GET['path'] . $file)) {

      $folders[] = [
        'file' => FS_DIR_APP . $_GET['path'] . $file .'/',
        'name' => $file .'/',
        'path' => $_GET['path'] . $file .'/',
        'size' => functions::file_size(FS_DIR_APP . $_GET['path'] . $file),
        'date_updated' => date('Y-m-d H:i:s', filemtime(FS_DIR_APP . $_GET['path'] . $file)),
        'date_created' => date('Y-m-d H:i:s', filectime(FS_DIR_APP . $_GET['path'] . $file)),
      ];

    } else {

      switch (true) {
        case (preg_match('#\.(a?png|bmp|gif|ico|jpe?g|webp|tiff?)$#i', $file)):
         $fonticon = 'fa-file-image-o';
         break;

        case (preg_match('#\.(css|html|js|less|php|scss)$#i', $file)):
         $fonticon = 'fa-file-code-o';
         break;

        case (preg_match('#\.(doc|pdf|txt|csv)$#i', $file)):
         $fonticon = 'fa-file-text-o';
         break;

        default:
          $fonticon = 'fa-file-o';
          break;
      }

      $files[] = [
        'file' => FS_DIR_APP . $_GET['path'] . $file,
        'name' => $file,
        'path' => $_GET['path'] . $file,
        'extension' => strtolower(pathinfo($file, PATHINFO_EXTENSION)),
        'icon' => $fonticon,
        'size' => functions::file_size(FS_DIR_APP . $_GET['path'] . $file),
        'date_updated' => date('Y-m-d H:i:s', filemtime(FS_DIR_APP . $_GET['path'] . $file)),
        'date_created' => date('Y-m-d H:i:s', filectime(FS_DIR_APP . $_GET['path'] . $file)),
      ];
    }
  }

  $folder_size = array_sum(array_column($folders, 'size')) + array_sum(array_column($files, 'size'));
  $quota = 1 * 1024 * 1024 * 1024;
  $usage = ceil($folder_size / $quota * 100);
?>
<style>
.dropzone.in {
  position: relative;
  /*border: 2px dashed #999;*/
}
.dropzone .drag-notice {
  display: none;
}
.dropzone.in .drag-notice {
  content: ' ';
  position: absolute;
  top: 0;
  display: flex;
  width: 100%;
  height: 100%;
  justify-content: center;
  text-align: center;
  flex-direction: column;
  background: rgba(0, 0, 0, 0.25);
  font-size: 2.5em;
  color: #fff;
}
table .fa-folder {
  color: #7ccdff;
}
</style>

<div class="card card-app">
  <div class="card-header">
    <div class="card-title">
      <?php echo $app_icon; ?> <?php echo language::translate('title_files', 'Files'); ?>
    </div>
  </div>

  <?php echo functions::form_begin('upload_form', 'post', '', true); ?>
  <div class="card-action">
    <ul class="list-inline">
      <li><?php echo functions::form_file_field('new_files[]', 'multiple'); ?></li>
      <li><?php echo functions::form_button('upload', ['true', language::translate('title_upload', 'Upload')]); ?></li>
      <li><?php echo functions::form_button('create_folder', ['true', functions::draw_fonticon('fa-folder-o') .' '. language::translate('title_create_new_folder', 'Create New Folder')]); ?></li>
    </ul>
  </div>
  <?php echo functions::form_end(); ?>

  <?php echo functions::form_begin('search_form', 'get'); ?>
    <div class="card-filter">
      <div class="input-group" style="width: 640px;">
        <span class="input-group-text"><?php echo language::translate('title_location', 'Location'); ?></span>
        <?php echo functions::form_text_field('path', $_GET['path']); ?>
      </div>
      <a class="btn btn-default" href="<?php echo document::ilink(null, ['path' => '/']); ?>">Home</a>
      <a class="btn btn-default" href="<?php echo document::ilink(null, ['path' => 'storage/images/']); ?>">Images</a>
      <a class="btn btn-default" href="<?php echo document::ilink(null, ['path' => 'storage/logs/']); ?>">Logs</a>
      <a class="btn btn-default" href="<?php echo document::ilink(null, ['path' => 'frontend/templates/'.settings::get('template').'/']); ?>">Template</a>
      <div class="expandable"><?php echo functions::form_search_field('query', true, 'placeholder="'. language::translate('text_search_phrase_or_keyword', 'Search phrase or keyword') .'"'); ?></div>
      <?php echo functions::form_button('filter', language::translate('title_search', 'Search'), 'submit'); ?>
    </div>
  <?php echo functions::form_end(); ?>

  <?php echo functions::form_begin('files_form', 'post'); ?>
    <div class="dropzone">
      <table class="table table-striped table-hover table-sortable data-table">
        <thead>
          <tr>
            <th><?php echo functions::draw_fonticon('fa-check-square-o fa-fw', 'data-toggle="checkbox-toggle"'); ?></th>
            <th class="main"><?php echo language::translate('title_file', 'File'); ?></th>
            <th class="text-end"><?php echo language::translate('title_size', 'Size'); ?></th>
            <th class="text-end"><?php echo language::translate('title_permissions', 'Permissions'); ?></th>
            <th class="text-end"><?php echo language::translate('title_modified', 'Modified'); ?></th>
            <th class="text-end"><?php echo language::translate('title_created', 'Created'); ?></th>
            <th></th>
          </tr>
        </thead>

        <tbody>
          <?php if (!empty($_GET['path']) && $_GET['path'] != '/') { ?>
          <tr>
            <td colspan="7">
              <?php echo functions::draw_fonticon('fa-arrow-left fa-fw'); ?> <a href="<?php echo document::href_ilink(null, ['path' => (dirname($_GET['path']) == '.') ? '' : str_replace('\\', '/', dirname($_GET['path']))]); ?>"> <?php echo language::translate('title_back', 'Back'); ?></a>
            </td>
          </tr>
          <?php } ?>

          <?php foreach ($folders as $folder) { ?>
          <tr>
            <td><?php echo functions::form_checkbox('folders[]', $folder['path']); ?></td>
            <td class="folder"><?php echo functions::draw_fonticon('fa-folder fa-fw fa-lg'); ?> <a href="<?php echo document::href_ilink(null, ['path' => $folder['path']]); ?>"><?php echo $folder['name']; ?></a></td>
            <td class="text-end"><?php echo functions::file_format_size($folder['size']); ?></td>
            <td class="text-end"><tt><?php echo functions::file_permissions($folder['file']); ?></tt></td>
            <td class="text-end"><?php echo language::strftime(language::$selected['format_datetime'], strtotime($folder['date_updated'])); ?></td>
            <td class="text-end"><?php echo language::strftime(language::$selected['format_datetime'], strtotime($folder['date_created'])); ?></td>
            <td class="text-end">
              <a class="btn btn-default btn-sm edit" href="<?php echo document::href_ilink(__APP__.'/edit_folder', ['path' => $folder['path']]); ?>" title="<?php echo language::translate('title_edit', 'Edit'); ?>"><?php echo functions::draw_fonticon('fa-pencil'); ?></a>
            </td>
          </tr>
          <?php } ?>

          <?php foreach ($files as $file) { ?>
          <tr>
            <td><?php echo functions::form_checkbox('files[]', $file['path']); ?></td>
            <td class="file"><?php echo functions::draw_fonticon($file['icon'] . ' fa-fw fa-lg'); ?> <a href="<?php echo document::href_ilink(__APP__.'/edit_file', ['path' => $file['path']]); ?>"><?php echo $file['name']; ?></a></td>
            <td class="text-end"><?php echo functions::file_format_size($file['size']); ?></td>
            <td class="text-end"><tt><?php echo functions::file_permissions($file['file']); ?></tt></td>
            <td class="text-end"><?php echo language::strftime(language::$selected['format_datetime'], strtotime($file['date_updated'])); ?></td>
            <td class="text-end"><?php echo language::strftime(language::$selected['format_datetime'], strtotime($file['date_created'])); ?></td>
            <td class="text-end">
              <a class="btn btn-default btn-sm download" href="<?php echo document::href_ilink(__APP__.'/download', ['path' => $file['path']]); ?>" title="<?php echo language::translate('title_download', 'Download'); ?>"><?php echo functions::draw_fonticon('fa-download'); ?></a>
              <a class="btn btn-default btn-sm edit" href="<?php echo document::href_ilink(__APP__.'/edit_file', ['path' => $file['path']]); ?>" title="<?php echo language::translate('title_edit', 'Edit'); ?>"><?php echo functions::draw_fonticon('fa-pencil'); ?></a>
            </td>
          </tr>
          <?php } ?>
        </tbody>

        <tfoot>
          <td colspan="7">
            <?php echo language::translate('title_folders', 'Folders'); ?>: <?php echo count($folders); ?>,
            <?php echo language::translate('title_files', 'Files'); ?>: <?php echo count($files); ?>,
            <?php echo language::translate('title_folder_size', 'Folder Size'); ?>: <?php echo functions::file_format_size($folder_size); ?>
          </td>
        </tfoot>
      </table>

      <div class="drag-notice">
        <?php echo language::translate('text_drag_and_drop_files_here', 'Drag and drop files here'); ?>
      </div>

    </div>

    <div class="card-body">
      <fieldset id="actions">
        <legend><?php echo language::translate('text_with_selected', 'With selected'); ?>:</legend>
        <ul class="list-inline">
          <li><?php echo functions::form_button('delete', language::translate('title_delete', 'Delete'), 'submit', 'formnovalidate class="btn btn-danger" onclick="if (!confirm(\''. language::translate('text_are_you_sure', 'Are you sure?') .'\')) return false;"', 'delete'); ?></li>
        </ul>
      </fieldset>
    </div>
  <?php echo functions::form_end(); ?>
</div>

<script>
  $('button[name="create_folder"]').click(function(e){
    e.preventDefault();
    let folder_name = prompt("<?php echo language::translate('text_new_folder_name', 'New Folder Name'); ?>");
    if (!folder_name) return false;
    let form = $('<form method="post"><input name="mkdir" type="true"><input name="directory" type="hidden"></form>');
    $('input[name="directory"]').val(folder_name).closest('form').submit();
    console.log('x');
  });

  $('.folder .download').click(function(e){
    if (!confirm("<?php echo language::translate('text_are_you_sure', 'Are you sure?'); ?>")) return false;
  });

  $('.data-table :checkbox').change(function() {
    $('#actions').prop('disabled', !$('.data-table :checked').length);
  }).first().trigger('change');

  $('input[type="file"]').on({
    change: function(){
      $(this).closest('form').submit();
    },
    mouseenter: function(){
      $('.dropzone').addClass('in');
    },
    mouseleave: function(){
      $('.dropzone').removeClass('in');
    }
  });

  $('.dropzone').on({

    dragover: function(e){
      e.preventDefault();
      e.stopPropagation();
      $(this).addClass('in');
    },

    dragenter: function(e){
      $(this).addClass('in');
    },

    dragleave: function(e){
      let dropzone = this.getBoundingClientRect();
      if (e.originalEvent.x < dropzone.left || e.originalEvent.x > dropzone.left + dropzone.width
       || e.originalEvent.y < dropzone.top || e.originalEvent.y > dropzone.top + dropzone.height) {
        $(this).removeClass('in');
      }
    },

    drop: function(e) {
      e.stopPropagation();
      e.preventDefault();

      let items = e.originalEvent.dataTransfer.items;

      getFilesDataTransferItems(items).then(files => {

        let form_data = new FormData();

        $.each(files, function(i, file) {
          form_data.append('files[]', file);
          form_data.append('paths[]', file.relpath);
        });

        form_data.append('upload', 'true');

        $.ajax({
          type: 'post',
          data: form_data,
          processData: false,
          contentType: false,
          success: function(e){
            location.reload();
          }
        });
      });

      $(this).removeClass('in');
    }
  });

  function getFilesDataTransferItems(dataTransferItems) {
    function traverseFileTreePromise(item, path = '', files) {
      return new Promise(resolve => {
        if (item.isFile) {
          item.file(file => {
            file.relpath = (path || '') + file.name;
            files.push(file);
            resolve(file);
          });
        } else if (item.isDirectory) {
          let dirReader = item.createReader();
          dirReader.readEntries(entries => {
            let entriesPromises = [];
            for (let entr of entries)
              entriesPromises.push(
                traverseFileTreePromise(entr, (path || '') + item.name + '/', files)
              );
            resolve(Promise.all(entriesPromises));
          });
        }
      });
    }

    let files = [];
    return new Promise((resolve, reject) => {
      let entriesPromises = [];
      for (let it of dataTransferItems)
        entriesPromises.push(
          traverseFileTreePromise(it.webkitGetAsEntry(), null, files)
        );
      Promise.all(entriesPromises).then(entries => {
        resolve(files);
      });
    });
  }
</script>