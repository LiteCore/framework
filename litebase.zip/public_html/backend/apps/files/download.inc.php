<?php
  if (empty($_GET['path'])) die('Missing path');

  $_GET['path'] = '/' . functions::file_resolve_path($_GET['path']);

  try {

    $realfile = functions::file_realpath('app://' . ltrim($_GET['path'], '/'));
    $filename = basename($realfile);

    if (!file_exists($realfile)) throw new Exception('No does not exist');

    if (!preg_match('#^'. preg_quote(FS_DIR_APP, '#') .'#', $realfile)) {
      throw new Exception(language::translate('error_access_forbidden', 'Access forbiden'));
    }

    if (is_dir($realfile)) {

      $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($realfile),
        RecursiveIteratorIterator::LEAVES_ONLY
      );

      $zip_file = functions::file_create_tempfile();

      $zip = new ZipArchive();
      if ($zip->open($zip_file, ZipArchive::CREATE)) {
        foreach ($files as $name => $file) {
          if (in_array(basename($file), ['.', '..'])) continue;
          $file = str_replace('\\', '/', $file);

          $zip->addFile($file, preg_replace('#^('. preg_quote(dirname($realfile) . '/', '#') .')#', '', $file));
        }
      }
      $zip->close();

      $realfile = $zip_file;
      $filename .= '.zip';
    }

    header('Cache-Control: must-revalidate');
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename='. $filename);
    header('Content-Length: ' . functions::file_size($realfile));
    header('Expires: 0');

    ob_end_clean();
    readfile($realfile);
    exit;

  } catch (Exception $e) {
    notices::add('errors', $e->getMessage());
  }