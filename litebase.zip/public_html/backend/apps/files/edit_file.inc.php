<?php
  if (empty($_GET['path'])) die('No file');

  $_GET['path'] = functions::file_resolve_path(ltrim($_GET['path'], '/'));

  if ((!$file = functions::file_realpath('app://' . $_GET['path'])) || !is_file($file) || !preg_match('#^'. preg_quote(FS_DIR_APP, '#') .'#', $file)) {
    die('Invalid file');
  }

  if (!empty($_GET['path'])) {
    $prefix = '';
    foreach (array_slice(explode('/', $_GET['path']), 0, -1) as $part) {
      breadcrumbs::add($part, document::ilink(__APP__.'/files', ['path' => $prefix .'/'. $part . '/']));
      $prefix .= '/' . $part;
    }
    breadcrumbs::add(basename($_GET['path']));
  }

  if (functions::file_is_binary('app://' . $_GET['path'])) {
    notices::add('warnings', 'File is a binary file');
    $disable_editing = true;
  }

  if (!$_POST) {
    $_POST['filename'] = $_GET['path'];
    $_POST['mode'] = substr(sprintf('%o', fileperms($file)), -4);
    $_POST['content'] = file_get_contents($file);
  }

  if (!empty($_POST['save'])) {

    try {

      if (!preg_match('#^'. preg_quote(FS_DIR_APP, '#') .'#', FS_DIR_APP . ltrim(functions::file_resolve_path($_POST['filename']), '/'))) {
        throw new Exception(language::translate('error_access_forbidden', 'Access forbidden'));
      }

      chmod($file, $_POST['mode']);

      if (empty($disable_editing)) {
        file_put_contents($file, $_POST['content']);
      }

      if ($file != functions::realpath('app://' . ltrim($_POST['filename'], '/'))) {
        if (!is_dir(dirname('app://' . ltrim($_POST['filename'], '/')))) {
          mkdir(dirname('app://' . ltrim($_POST['filename'], '/')));
        }
        rename($file, 'app://' . ltrim($_POST['filename'], '/'));
      }

      header('Location: '. document::ilink(__APP__.'/files', ['path' => dirname($_POST['filename'])]));
      exit;

    } catch (Exception $e) {
      notices::add('errors', $e->getMessage());
    }
  }

?>
<style>
textarea[name="content"] {
  background: #2f3244;
  color: #fff;
  height: 640px;
  font-family: Lucida Console, Monospace;
}
</style>

<div class="card card-app" style="min-width: 800px;">
  <div class="card-header">
    <div class="card-title">
      <?php echo $app_icon; ?> <?php echo language::translate('title_edit_file', 'Edit File'); ?>
    </div>
  </div>

  <div class="card-body">
    <?php echo functions::form_begin('file_form', 'post'); ?>

      <div class="row" style="max-width: 640px;">
        <div class="form-group col-md-8">
          <label><?php echo language::translate('title_filename', 'Filename'); ?></label>
          <?php echo functions::form_text_field('filename', true); ?>
        </div>

        <div class="form-group col-md-4">
          <label><?php echo language::translate('title_mode', 'Mode'); ?></label>
          <?php echo functions::form_text_field('mode', true); ?>
        </div>
      </div>

      <div class="form-group">
        <label><?php echo language::translate('title_content', 'Content'); ?></label>
        <?php echo functions::form_textarea('content', true, !empty($disable_editing) ? 'placeholder="Binary Data" disabled' : ''); ?>
      </div>

      <div class="card-action">
        <?php echo functions::form_button('save', language::translate('title_save', 'Save'), 'submit', 'class="btn btn-success"', 'save'); ?>
        <?php echo !empty($file) ? functions::form_button('delete', language::translate('title_delete', 'Delete'), 'submit', 'formnovalidate class="btn btn-danger" onclick="if (!window.confirm(\''. language::translate('text_are_you_sure', 'Are you sure?') .'\')) return false;"', 'delete') : false; ?>
        <?php echo functions::form_button('cancel', language::translate('title_cancel', 'Cancel'), 'button', 'onclick="history.go(-1);"', 'cancel'); ?>
      </div>

    <?php echo functions::form_end(); ?>
  </div>
</div>