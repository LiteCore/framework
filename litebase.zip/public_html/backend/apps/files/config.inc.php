<?php

  return $app_config = [
    'name' => language::translate('title_files', 'Files'),
    'default' => 'files',
    'priority' => 0,
    'theme' => [
      'color' => '#7ccdff',
      'icon' => 'fa-folder',
    ],
    'menu' => [],
    'docs' => [
      'download' => 'download.inc.php',
      'edit_file' => 'edit_file.inc.php',
      'edit_folder' => 'edit_folder.inc.php',
      'files' => 'files.inc.php',
    ],
  ];
