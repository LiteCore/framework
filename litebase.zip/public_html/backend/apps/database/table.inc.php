<?php
  if (empty($_GET['page']) || !is_numeric($_GET['page'])) $_GET['page'] = 1;
  if (empty($_GET['name'])) $_GET['name'] = reference::database(1)->tables[0]['name'];

  if (!in_array($_GET['name'], array_column(reference::database(1)->tables, 'name'))) {
    die('Invalid table');
  }

  if (empty($_POST['query'])) {
    $_POST['query'] = "select * from `". database::input($_GET['name']) ."`;";
  }

  breadcrumbs::add($_GET['name'], document::ilink(__APP__.'/table', ['name' => $_GET['name']]));

// Table Rows
  $rows = [];

  $query = database::query($_POST['query']);

  $affected_rows = database::affected_rows();
  if (preg_match('#^\s*(INSERT|UPDATE|DELETE|ALTER) #i', $_POST['query'])) {
    notices::add('notices', strtr(language::translate('notice_n_rows_affected', '%n rows affected'), ['%n' => $affected_rows]));
  }

  if (($query instanceof database_result)) {
    if ($_GET['page'] > 1) database::seek($query, settings::get('data_table_rows_per_page') * ($_GET['page'] - 1));

    $page_items = 0;
    while ($row = database::fetch($query)) {
      $rows[] = $row;
      if (++$page_items == settings::get('data_table_rows_per_page')) break;
    }

    $num_rows = database::num_rows($query);

  } else {
    $num_rows = 0;
  }

// Pagination
  $num_pages = ceil($num_rows/settings::get('data_table_rows_per_page'));

  $columns = $query->fields();

/*
  $operator_options = [
    ['='], ['!='], ['<'], ['<='], ['>'], ['>='],
    ['LIKE'], ['NOT LIKE'], ['IN'], ['NOT IN'], ['FIND_IN_SET'], ['NOT FIND_IN_SET'],
    ['IS NULL'], ['IS NOT NULL'], ['REGEXP'], ['NOT REGEXP'],
  ];
*/

  $primary_column = reference::database_table($_GET['name'])->primary_column;
?>
<style>
.nav-pills .nav-link {
  padding: .25em .5em !important;
}
.card-app .columns {
  columns: auto 200px;
}
.card-body {
  /*font-size: .85em;*/
}
.card-app table {
  /*font-family: Monospace;*/
}
.card-app table td {
  overflow-x: hidden;
  text-overflow: ellipsis;
  max-width: 250px;
}
.card-app table em {
  opacity: .5;
}
textarea[name="query"] {
  font-family: Monospace;
}
.card-app table tr td:not(:first-child):not(:last-child) {
  border-inline-start: 1px solid var(--table-border-color);
}
</style>


<div class="card card-app">

  <?php if (!empty($_GET['name'])) { ?>
  <nav class="nav nav-tabs">
    <a class="nav-link" href="<?php echo document::href_ilink(__APP__.'/structure', [], ['table']); ?>"><?php echo language::translate('title_structure', 'Structure'); ?></a>
    <a class="nav-link active" href="<?php echo document::href_ilink(__APP__.'/table', [], ['name']); ?>"><?php echo language::translate('title_data', 'Data'); ?></a>
  </nav>
  <?php } ?>

  <div class="card-header">
    <div class="card-title">
      <?php echo $app_icon; ?> <?php echo language::translate('title_table_data', 'Table Data'); ?>
    </div>
  </div>

  <div class="card-action">
    <ul class="list-inline">
      <li><a class="btn btn-default" href="<?php echo document::href_ilink(__APP__.'/edit_table', [], ['name']); ?>"><?php echo functions::draw_fonticon('fa-pencil'); ?> <?php echo language::translate('title_edit_table_structure', 'Edit Table Structure'); ?></a></li>
      <li><a class="btn btn-default" href="<?php echo document::href_ilink(__APP__.'/edit_row', ['table' => $_GET['name']]); ?>"><?php echo functions::draw_fonticon('fa-plus'); ?> <?php echo language::translate('title_create_new_row', 'Create New Row'); ?></a></li>
    </ul>
  </div>

<?php /*
        <div class="card-body box white">
          <h2><?php echo language::translate('title_tables', 'Tables'); ?></h2>

          <nav class="nav nav-pills nav-stacked">
            <?php foreach (reference::database(1)->tables as $table) { ?>
              <a class="nav-link<?php echo ($_GET['name'] == $table['name']) ? ' active' : ''; ?>" href="<?php echo document::link(null, ['doc' => 'data', 'table' => $table['name']]); ?>"><?php echo $table['name']; ?></a>
            <?php } ?>
          </nav>
        </div>
*/ ?>
  <div class="card-body">
    <?php echo functions::form_begin('query_form', 'post', '', false, 'style="max-width: 100vw;"'); ?>
      <div class="form-group">
        <?php echo functions::form_textarea('query', true); ?>
      </div>

      <div class="form-group">
        <?php echo functions::form_button('pretty_print', language::translate('title_pretty_print', 'Pretty Print'), 'button'); ?>
        <?php echo functions::form_button('run', language::translate('title_run_query', 'Run Query'), 'submit', 'class="btn btn-success"'); ?>
      </div>
    <?php echo functions::form_end(); ?>
  </div>

  <?php if (!empty($columns)) { ?>
  <div class="card-body">
    <fieldset id="toggle-columns">
      <legend><?php echo language::translate('title_toggle_columns', 'Toggle Columns'); ?></legend>
      <div class="columns">
      <?php foreach (array_slice($columns, 0, 10) as $column) echo functions::form_checkbox('columns[]', [$column, $column], !empty($_POST['columns']) ? true : $column); ?>
      <?php foreach (array_slice($columns, 10) as $column) echo functions::form_checkbox('columns[]', [$column, $column], true); ?>
      </div>
    </fieldset>
  </div>

  <div style="overflow-x: auto;">
    <table class="table table-striped table-hover table-sortable data-table">
      <thead>
        <tr>
          <th><?php echo functions::draw_fonticon('fa-check-square-o fa-fw', 'data-toggle="checkbox-toggle"'); ?></th>
          <?php foreach ($columns as $column) echo '<th>'. $column .'</th>'; ?>
          <th class="main"></th>
        </tr>
      </thead>

      <tbody>
        <?php foreach ($rows as $row) { ?>
        <tr>
          <td><?php echo !empty($row[$primary_column]) ? functions::form_checkbox('rows[]', $row[$primary_column]) : '--'; ?></td>
          <?php foreach ($row as $column => $value) echo '<td>'. (isset($value) ? addcslashes(functions::escape_html($value), "\t\r\n") : '<em>NULL</em>') .'</td>'; ?>
          <td class="text-end"><a class="btn btn-default btn-sm" href="<?php echo document::href_ilink(__APP__.'/edit_row', ['table' => $_GET['name'], $primary_column => $row[$primary_column]]); ?>" title="<?php echo language::translate('title_edit', 'Edit'); ?>"><?php echo functions::draw_fonticon('fa-pencil'); ?></a></td>
        </tr>
        <?php } ?>
      </tbody>

      <tfoot>
        <td colspan="<?php echo count($columns) + 2; ?>">
          <?php echo language::translate('title_rows', 'Rows'); ?>: <?php echo $num_rows; ?>
        </td>
      </tfoot>
    </table>
  </div>
  <?php } ?>

  <?php if (!empty($rows) && in_array($primary_column, $columns)) { ?>
  <div class="card-body">
    <fieldset id="actions">
      <legend><?php echo language::translate('text_with_selected', 'With selected'); ?></legend>

      <ul class="list-inline">
        <li><?php echo functions::form_button('delete', language::translate('title_delete', 'Delete'), 'submit', 'formnovalidate class="btn btn-danger" onclick="if (!confirm(\''. language::translate('text_are_you_sure', 'Are you sure?') .'\')) return false;"', 'delete'); ?></li>
      </ul>
    </fieldset>
  </div>
  <?php } ?>

  <?php if ($columns && $num_pages > 1) { ?>
  <div class="card-footer">
    <?php echo functions::draw_pagination($num_pages); ?>
  </div>
  <?php } ?>
</div>

<script>

  $('textarea[name="query"]').on('input', function(e) {
    $(this).height(0);
    $(this).height(this.scrollHeight - 15);
  });

  $('#toggle-columns :input').change(function() {
    let index = $(this).closest('.form-check').index() + 1;
    if ($(this).is(':checked')) {
      $('.data-table thead tr th').eq(index).show();
      $('.data-table tbody tr').each(function(){
        $(this).find('td').eq(index).show();
      });
    } else {
      $('.data-table thead tr th').eq(index).hide();
      $('.data-table tbody tr').each(function(){
        $(this).find('td').eq(index).hide();
      });
    }
  }).trigger('change');

  $('.data-table :checkbox').change(function() {
    $('#actions').prop('disabled', !$('.data-table :checked').length);
  }).first().trigger('change');

  $('button[name="pretty_print"]').click(function() {
    $.post('<?php echo document::ilink(__APP__.'/pretty_print'); ?>', {
      'query': $('form[name="query_form"] textarea[name="query"]').val(),
    }).then(function(response){
      $('form[name="query_form"] textarea[name="query"]').val(response).trigger('input');
    });
  });
</script>
