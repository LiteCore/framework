<?php

  $app_config = [
    'name' => language::translate('title_database', 'Database'),
    'default' => 'tables',
    'priority' => 0,
    'theme' => [
      'color' => '#c7a250',
      'icon' => 'fa-database',
    ],
    'menu' => [
      [
        'title' => language::translate('title_tables', 'Tables'),
        'doc' => 'tables',
        'params' => [],
      ],
      [
        'title' => language::translate('title_query', 'Query'),
        'doc' => 'table',
        'params' => [],
      ],
    ],
    'docs' => [
      'tables' => 'tables.inc.php',
      'table' => 'table.inc.php',
      'structure' => 'structure.inc.php',
      'edit_row' => 'edit_row.inc.php',
      'edit_table' => 'edit_table.inc.php',
      'pretty_print' => 'pretty_print.inc.php',
    ],
  ];
/*
  foreach (reference::database()->tables as $table) {
    $app_config['menu'][] = [
      'title' => $table['name'],
      'doc' => 'data',
      'params' => ['table' => $table['name']],
    ];
  }
*/
  return $app_config;
