<?php

  if (empty($_GET['name'])) $_GET['name'] = reference::database(1)->tables[0]['name'];

  if (!in_array($_GET['name'], array_column(reference::database(1)->tables, 'name'))) {
    die('Invalid table');
  }

  breadcrumbs::add(language::translate('title_database', 'Database'), document::ilink(__APP__.'/table'));
  breadcrumbs::add($_GET['name']);

  $column_types = [
    [
      'label' => 'Common',
      'options' => [
        ['int', 'int', 'data-length="11"'],
        ['float', 'float', 'data-length=""'],
        ['varchar', 'varchar', 'data-length="80"'],
        ['text', 'text', 'data-length=""'],
        ['timestamp', 'timestamp', 'data-length=""'],
      ],
    ],
    [
      'label' => 'Alphanumerical',
      'options' => [
        ['char', 'char', 'data-length="80"'],
        ['varchar', 'varchar', 'data-length="80"'],
        ['text', 'text', 'data-length=""'],
        ['tinytext', 'tinytext', 'data-length=""'],
        ['smalltext', 'smalltext', 'data-length=""'],
        ['mediumtext', 'mediumtext', 'data-length=""'],
        ['longtext', 'longtext', 'data-length=""'],
      ],
    ],
    [
      'label' => 'Numerical',
      'options' => [
        ['int', 'int', 'data-length="11"'],
        ['float', 'float', 'data-length="11,4"'],
        ['double', 'double', 'data-length="22,8"'],
        ['tinyint', 'tinyint', 'data-length=""'],
        ['smallint', 'smallint', 'data-length=""'],
        ['mediumint', 'mediumint', 'data-length=""'],
        ['bigint', 'bigint', 'data-length=""'],
      ],
    ],
    [
      'label' => 'Date/Time',
      'options' => [
        ['date', 'date', 'data-length="11"'],
        ['time', 'time', 'data-length=""'],
        ['year', 'year', 'data-length=""'],
        ['datetime', 'datetime', 'data-length=""'],
        ['timestamp', 'timestamp', 'data-length=""'],
      ],
    ],
    [
      'label' => 'Binary',
      'options' => [
        ['binary', 'binary', 'data-length="11"'],
        ['blob', 'blob', 'data-length=""'],
        ['varbinary', 'varbinary', 'data-length=""'],
      ],
    ],
  ];

?>
<style>
.card-app table {
  /*font-family: Monospace;*/
}
.card-app table td:not([class="main"]) {
  white-space: nowrap;
}
.card-app table td input,
.card-app table td select {
  min-width: max-content;
}
.card-app table tr td:not(:first-child):not(:last-child) {
  border-inline-start: 1px solid var(--table-border-color);
}
</style>

<div class="card card-app">

  <nav class="nav nav-tabs">
    <a class="nav-link" href="<?php echo document::href_ilink(__APP__.'/structure', [], ['table']); ?>"><?php echo language::translate('title_structure', 'Structure'); ?></a>
    <a class="nav-link" href="<?php echo document::href_ilink(__APP__.'/table', [], ['name']); ?>"><?php echo language::translate('title_data', 'Data'); ?></a>
  </nav>

  <div class="card-header">
    <div class="card-title">
      <?php echo $app_icon; ?> <?php echo language::translate('title_table_structure', 'Table Structure'); ?>
    </div>
  </div>

  <table class="table table-striped table-hover table-sortable rows-table">
    <thead>
      <tr>
        <th><?php echo functions::draw_fonticon('fa-check-square-o fa-fw', 'data-toggle="checkbox-toggle"'); ?></th>
        <th></th>
        <th><?php echo language::translate('title_column', 'Column'); ?></th>
        <th colspan="2"><?php echo language::translate('title_type', 'Type'); ?></th>
        <th><?php echo language::translate('title_nullable', 'Nullable'); ?></th>
        <th><?php echo language::translate('title_default', 'Default'); ?></th>
        <th><?php echo language::translate('title_collation', 'Collation'); ?></th>
        <th class="main"><?php echo language::translate('title_comment', 'Comment'); ?></th>
        <th></th>
      </tr>
    </thead>

    <tbody>
      <?php foreach (reference::database_table($_GET['name'])->columns as $column) { ?>
      <?php if (!empty($_GET['edit_column']) && $_GET['edit_column'] == $column['name']) { ?>
      <tr>
        <td></td>
        <td>
          <?php echo ($column['key'] == 'PRI') ? functions::draw_fonticon('fa-key', 'style="color: #e5d72c;"') : ''; ?>
          <?php echo ($column['key'] == 'UNI') ? functions::draw_fonticon('fa-key', 'style="color: #e52c2c;"') : ''; ?>
          <?php echo ($column['key'] == 'MUL') ? functions::draw_fonticon('fa-key', 'style="color: #7ce52c;"') : ''; ?>
        </td>
        <td><?php echo functions::form_text_field('column[name]', !empty($_POST) ? true : $column['name']); ?></td>
        <td><?php echo functions::form_select_optgroup_field('column[type]', $column_types, !empty($_POST) ? true : $column['type']); ?></td>
        <td><?php echo functions::form_text_field('column[length]', !empty($_POST) ? true : $column['length']); ?></td>
        <td><?php echo functions::form_checkbox('column[null]', 'YES', !empty($_POST) ? true : $column['null']); ?></td>
        <td><?php echo functions::form_text_field('column[default]', !empty($_POST) ? true : $column['default'], 'list="default-options"'); ?></td>
        <td><?php echo functions::form_mysql_collations_list('column[collation]', !empty($_POST) ? true : $column['collation']); ?></td>
        <td><?php echo functions::form_text_field('column[comment]', !empty($_POST) ? true : $column['comment']); ?></td>
        <td class="text-end">
          <button class="btn btn-success" name="save" value="true" type="submit" title="<?php echo language::translate('title_save', 'Save'); ?>"><?php echo functions::draw_fonticon('fa-save'); ?></button>
          <button class="btn btn-default" name="save" value="true" type="button" title="<?php echo language::translate('title_cancel', 'Cancel'); ?>"><?php echo functions::draw_fonticon('fa-times'); ?></button>
        </td>
      </tr>
      <?php } else { ?>
      <tr<?php echo ($column['key'] == 'PRI') ? ' style="font-weight: bold;"' : ''; ?>>
        <td><?php echo functions::form_checkbox('columns[]', $column['name']); ?></td>
        <td>
          <?php echo ($column['key'] == 'PRI') ? functions::draw_fonticon('fa-key', 'style="color: #e5d72c;"') : ''; ?>
          <?php echo ($column['key'] == 'UNI') ? functions::draw_fonticon('fa-key', 'style="color: #e52c2c;"') : ''; ?>
          <?php echo ($column['key'] == 'MUL') ? functions::draw_fonticon('fa-key', 'style="color: #7ce52c;"') : ''; ?>
        </td>
        <td><?php echo $column['name']; ?></td>
        <td colspan="2"><?php echo $column['type']; ?></td>
        <td><?php echo $column['null'] ? language::translate('title_yes', 'Yes') : language::translate('title_no', 'No'); ?></td>
        <td><?php echo $column['default']; ?></td>
        <td><?php echo $column['collation']; ?></td>
        <td><?php echo $column['comment']; ?></td>
        <td class="text-end"><a class="btn btn-default btn-sm" href="<?php echo document::href_ilink(__APP__.'/structure', ['edit_column' => $column['name']], ['table']); ?>" title="<?php echo language::translate('title_edit', 'Edit'); ?>"><?php echo functions::draw_fonticon('fa-pencil'); ?></a></td>
      </tr>
      <?php } ?>
      <?php } ?>
    </tbody>

    <tfoot>
      <td colspan="10">
        <?php echo language::translate('title_columns', 'Columns'); ?>: <?php echo count(reference::database_table($_GET['name'])->columns); ?>
      </td>
    </tfoot>
  </table>
</div>

<div class="card card-app">
  <div class="card-header">
    <h2 class="card-title"><?php echo language::translate('title_table_index', 'Table Index'); ?></h2>
  </div>

  <table class="table table-striped table-hover table-sortable data-table">
    <thead>
      <tr>
        <th><?php echo functions::draw_fonticon('fa-check-square-o fa-fw', 'data-toggle="checkbox-toggle"'); ?></th>
        <th></th>
        <th><?php echo language::translate('title_name', 'Name'); ?></th>
        <th><?php echo language::translate('title_type', 'Tyoe'); ?></th>
        <th><?php echo language::translate('title_columns', 'Columns'); ?></th>
        <th><?php echo language::translate('title_cardinality', 'Cardinality'); ?></th>
        <th><?php echo language::translate('title_type', 'Type'); ?></th>
        <th class="main"><?php echo language::translate('title_comment', 'Comment'); ?></th>
        <th></th>
      </tr>
    </thead>

    <tbody>
      <?php foreach (reference::database_table($_GET['name'])->indexes as $index) { ?>
      <tr<?php echo ($index['kind'] == 'primary') ? ' style="font-weight: bold;"' : ''; ?>>
        <td><?php echo functions::form_checkbox('columns[]', $column['name']); ?></td>
        <td>
          <?php echo ($index['kind'] == 'primary') ? functions::draw_fonticon('fa-key', 'style="color: #e5d72c;"') : ''; ?>
          <?php echo ($index['kind'] == 'unique') ? functions::draw_fonticon('fa-key', 'style="color: #e52c2c;"') : ''; ?>
          <?php echo ($index['kind'] == 'key') ? functions::draw_fonticon('fa-key', 'style="color: #7ce52c;"') : ''; ?>
        </td>
        <td><?php echo $index['name']; ?></td>
        <td><?php echo $index['kind']; ?></td>
        <td><?php echo implode(', ', $index['columns']); ?></td>
        <td><?php echo $index['cardinality']; ?></td>
        <td><?php echo $index['type']; ?></td>
        <td><?php echo $index['comment']; ?></td>
        <td class="text-end"><a class="btn btn-default btn-sm" href="<?php echo document::href_ilink(__APP__.'/edit_table', ['action' => 'edit', 'index' => $index['name']]); ?>" title="<?php echo language::translate('title_edit', 'Edit'); ?>"><?php echo functions::draw_fonticon('fa-pencil'); ?></a></td>
      </tr>
      <?php } ?>
    </tbody>

    <tfoot>
      <td colspan="9">
        <?php echo language::translate('title_indexes', 'Indexes'); ?>: <?php echo count(reference::database_table($_GET['name'])->indexes); ?>
      </td>
    </tfoot>
  </table>

</div>

<datalist id="default-options">
  <option value="NULL"></option>
  <option value="current_timestamp()"></option>
</datalist>

