<?php

  if (empty($_GET['table']) || !in_array($_GET['table'], array_column(reference::database(DB_DATABASE)->tables, 'name'))) {
    die('Invalid table');
  }

  breadcrumbs::add(language::translate('title_database', 'Database'), document::ilink(__APP__.'/tables'));
  breadcrumbs::add($_GET['table']);

  $columns = reference::database_table($_GET['table'])->columns;
  $primary_column = reference::database_table($_GET['table'])->primary_column;

  if (!empty($_GET[$primary_column])) {
    $row = database::query(
      "select * from ". database::input($_GET['table']) ."
      where $primary_column = '". database::input($_GET[$primary_column]) ."'
      limit 1;"
    )->fetch();
  } else {
    $row = [];
    foreach ($columns as $column) {
      $row[$column['name']] = $column['default'];
    }
  }

  if (!$_POST) {
    $_POST = $row;
    foreach ($columns as $column) {
      $_POST['null'][$column['name']] = (!empty($column['null']) && !isset($_POST[$column['name']])) ? '1' : '0';
    }
  }

  if (isset($_POST['save'])) {

    try {

      $fields = array_column($columns, 'name');

      foreach ($fields as $field) {
        if (isset($_POST[$field])) $row[$field] = $_POST[$field];
        if (!empty($_POST['null'][$field])) $row[$field] = null;
      }

      $map_insert_values = function($key, $value){ return isset($value) ? "'". database::input($value) ."'" : "null"; };
      $map_update_values = function($key, $value){ return "`". database::input($key) ."` = ". (isset($value) ? "'". database::input($value) ."'" : "null"); };

      if (empty($_GET[$primary_column])) {
        database::query(
          "insert into `". database::input($_GET['table']) ."`
          (`". implode("`, `", database::input(array_keys($row))) ."`)
          values (". implode(", ", array_map($map_insert_values, array_keys($row), $row)) .");"
        );
      } else {
        database::query(
          "update `". database::input($_GET['table']) ."`
          set ". implode(", ", array_map($map_update_values, array_keys($row), $row)) ."
          where `". database::input($primary_column) ."` = '". database::input($_GET[$primary_column]) ."'
          limit 1;"
        );
      }

      notices::add('success', language::translate('success_changes_saved', 'Changes saved'));
      header('Location: '. document::ilink(__APP__.'/table', [], ['name']));
      exit;

    } catch (Exception $e) {
      notices::add('errors', $e->getMessage());
    }
  }

  $draw_input_field = function($column) {
    switch (true) {

      case (preg_match('#^enum\((.*)\)$#', $column['type'], $matches)):
        $options = array_merge([''], preg_split('#\'\s*(?!\\\\),\s*\'#', trim($matches[1], "'"), -1, PREG_SPLIT_NO_EMPTY));
        return functions::form_select_field($column['name'], $options, true);

      case (preg_match('#^((tiny|small|medium|big)?int|bytes)\(([0-9]+)\)( unsigned)?#i', $column['type'], $matches)):
        return functions::form_number_field($column['name'], true, 'size="'. $matches[3] .'" maxlength="'. $matches[3] .'"' . (isset($matches[4]) ? ' min="0"' : ''));

      case (preg_match('#^(float|double|decimal)\(([0-9]+)?(?:,([0-9]+))?\)( unsigned)?#', $column['type'], $matches)):
        return functions::form_decimal_field($column['name'], true, isset($matches[3]) ? $matches[3] : 4, 'size="'. ($matches[2]) .'" maxlength="'. $matches[2] .'"' . (isset($matches[4]) ? ' min="0"' : ''));

      case (preg_match('#^(timestamp|datetime)$#', $column['type'])):
        return functions::form_datetime_field($column['name'], true, 'size="19" maxlength="19"');

      case (preg_match('#^date$#', $column['type'])):
        return functions::form_date_field($column['name'], true, 'size="10" maxlength="10"');

      case (preg_match('#^time$#', $column['type'])):
        return functions::form_time_field($column['name'], true, 'size="8" maxlength="8"');

      default:
        if (preg_match('#\(([0-9]+)\)$#', $column['type'], $matches) && $matches[1] <= 128)  {
          return functions::form_text_field($column['name'], true, 'size="'. $matches[1] .'" maxlength="'. $matches[1] .'"');
        } else if (isset($matches[1]) && $matches[1] <= 256)  {
          return functions::form_text_field($column['name'], true, 'style="height: 3em;" maxlength="'. $matches[1] .'"');
        } else if (isset($matches[1]) && $matches[1] <= 512)  {
          return functions::form_text_field($column['name'], true, 'style="height: 6em;" maxlength="'. $matches[1] .'"');
        } else{
          return functions::form_textarea($column['name'], true, 'style="height: 12em;"');
        }
    }
  };

?>
<style>
.card-app table {
  font-family: Monospace;
}
.card-app table input {
  text-align: inline-start;
}
.card-app table input[size],
.card-app table select {
  width: auto;
}
</style>

<div class="card card-app">
  <div class="card-header">
    <h1 class="card-title">
      <?php echo $app_icon; ?> <?php echo !empty($row[$primary_column]) ? language::translate('title_edit_row', 'Edit Row') : language::translate('title_create_new_row', 'Create New Row'); ?>
    </h1>
  </div>

  <?php echo functions::form_begin('row_form', 'post'); ?>
    <table class="table table-striped table-hover table-sortable table-dragable rows-table">
      <thead>
        <tr>
          <th><?php echo language::translate('title_name', 'Name'); ?></th>
          <th><?php echo language::translate('title_null', 'Null'); ?></th>
          <th class="main"><?php echo language::translate('title_value', 'Value'); ?></th>
        </tr>
      </thead>

      <tbody>
        <?php foreach ($columns as $column) { ?>
        <tr>
          <td><?php echo $column['name']; ?></td>
          <td><?php echo functions::form_checkbox('null['.$column['name'].']', '1', true, empty($column['null']) ? 'disabled' : ''); ?></td>
          <td><?php echo $draw_input_field($column); ?></td>
        </tr>
        <?php } ?>
      </tbody>

      <tfoot>
        <td colspan="3">
          <?php echo language::translate('title_columns', 'Columns'); ?>: <?php echo count($columns); ?>
        </td>
      </tfoot>
    </table>

    <div class="card-action">
      <?php echo functions::form_button('save', language::translate('title_save', 'Save'), 'submit', 'class="btn btn-success"', 'save'); ?>
      <?php echo !empty($row[$primary_column]) ? functions::form_button('delete', language::translate('title_delete', 'Delete'), 'submit', 'formnovalidate class="btn btn-danger" onclick="if (!window.confirm(\''. language::translate('text_are_you_sure', 'Are you sure?') .'\')) return false;"', 'delete') : false; ?>
      <?php echo functions::form_button('cancel', language::translate('title_cancel', 'Cancel'), 'button', 'onclick="history.go(-1);"', 'cancel'); ?>
    </div>

  <?php echo functions::form_end(); ?>
</div>

<script>
  $('input[name^="null\["]').change(function(){
    $(this).closest('tr').find('td:last-child :input').prop('disabled', $(this).is(':checked'));
  }).trigger('change');
</script>