<?php

  if (!empty($_GET['name'])) {
    $table = new ent_database_table($_GET['name']);
  } else {
    $table = new ent_database_table();
  }

  if (!$_POST) {
    $_POST = $table->data;
  }

  document::$snippets['title'][] = !empty($customer->data['id']) ? language::translate('title_edit_table', 'Edit Table') : language::translate('title_create_new_table', 'Create New Table');

  breadcrumbs::add(language::translate('title_database', 'Database'), document::ilink(__APP__.'/tables'));
  breadcrumbs::add($table->previous['name'],  document::ilink(__APP__.'/table', ['name' => $table->previous['name']]));

  if (isset($_POST['save'])) {

    try {

      $fields = [
        'name',
        'auto_increment',
        'collation',
        'engine',
        'columns',
        'indexes',
      ];

      foreach ($fields as $field) {
        if (isset($_POST[$field])) $table->data[$field] = $_POST[$field];
      }

      $table->save();

      notices::add('success', language::translate('success_changes_saved', 'Changes saved'));
      header('Location: '. document::ilink(__APP__.'/table', ['name' => $table->data['name']]));
      exit;

    } catch (Exception $e) {
      notices::add('errors', $e->getMessage());
    }
  }

  if (isset($_POST['delete'])) {

    try {
      if (empty($table->previous['name'])) throw new Exception(language::translate('error_must_provide_table', 'You must provide a table'));

      $table->delete();

      notices::add('success', language::translate('success_changes_saved', 'Changes saved'));
      header('Location: '. document::ilink(__APP__.'/tables'));
      exit;

    } catch (Exception $e) {
      notices::add('errors', $e->getMessage());
    }
  }

  $key_types = [
    'primary' => language::translate('title_primary_key', 'Primary Key'),
    'key' => language::translate('title_index_key', 'Index Key'),
    'unique' => language::translate('title_unique_key', 'Unique Key'),
  ];

  $column_types = [
    [
      'label' => 'Common',
      'options' => [
        ['tinyint', 'tinyint', 'data-length="4" data-unsigned=true data-default="0" data-collation=false'],
        ['int', 'int', 'data-length="11" data-unsigned=true data-default="0" data-collation=false'],
        ['float', 'float', 'data-length="11,4" data-unsigned=true data-default="0" data-collation=false'],
        ['varchar', 'varchar', 'data-length="65535" data-unsigned=false data-default="0" data-collation=true'],
        ['text', 'text', 'data-length="65535" data-unsigned=false data-default="" data-collation=true'],
        ['timestamp', 'timestamp', 'data-length="" data-unsigned=false data-default="" data-collation=false'],
        ['enum', 'enum', 'data-length="\'a\',\'b\'" data-unsigned=false data-default="" data-collation=true'],
      ],
    ],
    [
      'label' => 'Alphanumerical',
      'options' => [
        ['char', 'char', 'data-length="255" data-default="" data-collation=true'],
        ['varchar', 'varchar', 'data-length="65535" data-default="" data-collation=true'],
        ['text', 'text', 'data-length="65535" data-default="" data-collation=true'],
        ['tinytext', 'tinytext', 'data-length="255" data-default="" data-collation=true'],
        ['smalltext', 'smalltext', 'data-length="65535" data-default="" data-collation=true'],
        ['mediumtext', 'mediumtext', 'data-length="" data-default="" data-collation=true'],
        ['longtext', 'longtext', 'data-length="" data-default="" data-collation=true'],
      ],
    ],
    [
      'label' => 'Numerical',
      'options' => [
        ['int', 'int', 'data-length="11" data-unsigned=true data-default="0" data-collation=false'],
        ['float', 'float', 'data-length="11,4" data-max-size="4294967295" data-unsigned=true data-default="0" data-collation=false'],
        ['double', 'double', 'data-length="22,8" data-unsigned=true data-default="0" data-collation=false'],
        ['tinyint', 'tinyint', 'data-length="4" data-unsigned=true data-default="0" data-collation=false'],
        ['smallint', 'smallint', 'data-length="6" data-unsigned=true data-default="0" data-collation=false'],
        ['mediumint', 'mediumint', 'data-length="9" data-unsigned=true data-default="0" data-collation=false'],
        ['bigint', 'bigint', 'data-length="20" data-unsigned=true data-default="0" data-collation=false'],
      ],
    ],
    [
      'label' => 'Date/Time',
      'options' => [
        ['date', 'date', 'data-length="11" data-default="" data-unsigned=false'],
        ['time', 'time', 'data-length="" data-default="" data-unsigned=false'],
        ['year', 'year', 'data-length="" data-default="" data-unsigned=false'],
        ['datetime', 'datetime', 'data-length="" data-default="" data-unsigned=false'],
        ['timestamp', 'timestamp', 'data-length="" data-default="" data-unsigned=false'],
      ],
    ],
    [
      'label' => 'Binary',
      'options' => [
        ['binary', 'binary', 'data-length="11" data-default="" data-unsigned=false'],
        ['blob', 'blob', 'data-length="" data-default="65535" data-unsigned=false'],
        ['varbinary', 'varbinary', 'data-length="65535" data-default="" data-unsigned=false'],
      ],
    ],
  ];

?>
<style>
.card-app table {
  /*font-family: Monospace;*/
}
.card-app table td:not([class="main"]) {
  white-space: nowrap;
}
.card-app table.columns thead th,
.card-app table.columns tbody td {
  padding: .25em .5em;
}
.card-app table tfoot td {
  padding: 1em !important;
}
.card-app table td input,
.card-app table td select {
  min-width: max-content;
}
.card-app table tr td:not(:first-child):not(:last-child) {
  border-inline-start: 1px solid var(--table-border-color);
}
</style>

<div class="card card-app">

  <nav class="nav nav-tabs">
    <a class="nav-link active" href="<?php echo document::href_ilink(__APP__.'/structure', [], ['table']); ?>"><?php echo language::translate('title_structure', 'Structure'); ?></a>
    <a class="nav-link" href="<?php echo document::href_ilink(__APP__.'/table', [], ['name']); ?>"><?php echo language::translate('title_data', 'Data'); ?></a>
  </nav>

  <div class="card-header">
    <div class="card-title">
      <?php echo $app_icon; ?> <?php echo !empty($table->previous['name']) ? language::translate('title_edit_table', 'Edit Table') : language::translate('title_create_new_table', 'Create New Table'); ?>
    </div>
  </div>

  <?php echo functions::form_begin('closest_form', 'post'); ?>

    <div class="card-body">

      <div class="row">
        <div class="col-md-3">
          <h2><?php echo language::translate('title_general', 'General'); ?></h2>
          <div class="">
            <div class="form-group ">
              <label><?php echo language::translate('title_name', 'Name'); ?></label>
              <?php echo functions::form_text_field('name'); ?>
            </div>

            <div class="form-group ">
              <label><?php echo language::translate('title_auto_increment', 'Auto Increment'); ?></label>
              <?php echo functions::form_number_field('auto_increment', true); ?>
            </div>

            <div class="form-group ">
              <label><?php echo language::translate('title_collation', 'Collation'); ?></label>
              <?php echo functions::form_mysql_collations_list('collation', true); ?>
            </div>

            <div class="form-group ">
              <label><?php echo language::translate('title_engine', 'Engine'); ?></label>
              <?php echo functions::form_text_field('engine', (file_get_contents('php://input') == '') ? 'InnoDB' : true, 'readonly'); ?>
            </div>
          </div>

        </div>

        <div class="col-md-9">
          <h2><?php echo language::translate('title_indexes', 'Indexes'); ?></h2>

          <table class="indexes table table-striped table-hover table-sortable data-table">
            <thead>
              <tr>
                <th><?php echo functions::draw_fonticon('fa-check-square-o fa-fw', 'data-toggle="checkbox-toggle"'); ?></th>
                <th></th>
                <th><?php echo language::translate('title_name', 'Name'); ?></th>
                <th><?php echo language::translate('title_type', 'Type'); ?></th>
                <th><?php echo language::translate('title_columns', 'Columns'); ?></th>
                <th><?php echo language::translate('title_cardinality', 'Cardinality'); ?></th>
                <th class="main"><?php echo language::translate('title_type', 'Type'); ?></th>
                <th></th>
              </tr>
            </thead>

            <tbody>
              <?php foreach ($_POST['indexes'] as $key => $index) { ?>
              <tr<?php echo ($index['kind'] == 'primary') ? ' style="font-weight: bold;"' : ''; ?>>
                <td><?php echo functions::form_checkbox('selected_indexes[]', $key); ?></td>
                <td>
                  <?php echo functions::form_select_field('indexes['.$key.'][columns]', $key_types, $index['kind']) . $index['kind']; ?>
                  <?php echo ($index['kind'] == 'primary') ? functions::draw_fonticon('fa-key', 'style="color: #e5d72c;"') : ''; ?>
                  <?php echo ($index['kind'] == 'unique') ? functions::draw_fonticon('fa-key', 'style="color: #e52c2c;"') : ''; ?>
                  <?php echo ($index['kind'] == 'key') ? functions::draw_fonticon('fa-key', 'style="color: #7ce52c;"') : ''; ?>
                </td>
                <td><?php echo ($index['name'] == 'PRIMARY') ? $index['name'] : functions::form_text_field('indexes['.$key.'][name]', $index['name']); ?></td>
                <td><?php echo $index['kind']; ?></td>
                <td class="indexed-columns">
                  <?php foreach ($index['columns'] as $column) { ?>
                  <div class="column"><?php echo functions::form_hidden_field('indexes['.$key.'][columns][]', $column) . $column; ?></div>
                  <?php } ?>
                </td>
                <td><?php echo $index['cardinality']; ?></td>
                <td><?php echo functions::form_hidden_field('indexes['.$key.'][type]', true) . $index['type']; ?></td>
                <td class="text-end">
                  <button class="btn btn-danger btn-sm" name="remove" value="true" type="button" title="<?php echo language::translate('title_remove', 'Remove'); ?>"><?php echo functions::draw_fonticon('fa-trash'); ?></button>
                </td>
              </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <table class="columns table table-striped table-hover table-dragable data-table">
      <thead>
        <tr>
          <th><?php echo functions::draw_fonticon('fa-check-square-o fa-fw', 'data-toggle="checkbox-toggle"'); ?></th>
          <th></th>
          <th><?php echo language::translate('title_column', 'Column'); ?></th>
          <th><?php echo language::translate('title_type', 'Type'); ?></th>
          <th><?php echo language::translate('title_unsigned', 'Unsigned'); ?></th>
          <th><?php echo language::translate('title_length_set', 'Length/Set'); ?></th>
          <th><?php echo language::translate('title_nullable', 'Nullable'); ?></th>
          <th><?php echo language::translate('title_default', 'Default'); ?></th>
          <th><?php echo language::translate('title_collation', 'Collation'); ?></th>
          <th class="main"><?php echo language::translate('title_comment', 'Comment'); ?></th>
          <th><?php echo language::translate('title_move', 'Move'); ?></th>
          <th></th>
        </tr>
      </thead>

      <tbody>
        <?php foreach ($_POST['columns'] as $column) { ?>
        <tr>
          <td><?php echo functions::form_checkbox('selected_columns[]', '1'); ?></td>
          <td>
            <?php echo ($column['key'] == 'primary') ? functions::draw_fonticon('fa-key', 'style="color: #e5d72c;"') : ''; ?>
            <?php echo ($column['key'] == 'unique') ? functions::draw_fonticon('fa-key', 'style="color: #e52c2c;"') : ''; ?>
            <?php echo ($column['key'] == 'key') ? functions::draw_fonticon('fa-key', 'style="color: #7ce52c;"') : '';?>
          </td>
          <td><?php echo functions::form_text_field('columns['.$column['name'].'][name]', true); ?></td>
          <td><?php echo functions::form_select_optgroup_field('columns['.$column['name'].'][type]', $column_types, true); ?></td>
          <td><?php echo functions::form_checkbox('columns['.$column['name'].'][unsigned]', '1', true); ?></td>
          <td><?php echo functions::form_text_field('columns['.$column['name'].'][length]', true); ?></td>
          <td><?php echo functions::form_checkbox('columns['.$column['name'].'][null]', '1', true); ?></td>
          <td><?php echo functions::form_text_field('columns['.$column['name'].'][default]', true, 'list="default-options"'); ?></td>
          <td><?php echo functions::form_mysql_collations_list('columns['.$column['name'].'][collation]', true); ?></td>
          <td><?php echo functions::form_text_field('columns['.$column['name'].'][comment]', true); ?></td>
          <td class="grabable text-center"><?php echo functions::draw_fonticon('fa-arrows-v'); ?></td>
          <td class="text-end">
            <button class="btn btn-danger btn-sm" name="remove" value="true" type="button" title="<?php echo language::translate('title_remove', 'Remove'); ?>"><?php echo functions::draw_fonticon('fa-trash'); ?></button>
          </td>
        </tr>
        <?php } ?>
      </tbody>

      <tfoot>
        <td colspan="12">
          <button class="btn btn-default btn-" name="add_column" type="button"><?php echo functions::draw_fonticon('fa-plus'); ?> <?php echo language::translate('title_add_new_column', 'Add New Column'); ?></a>
          <button class="btn btn-default btn-" name="add_primary_key" type="button" data-require-columns="true" data-kind="primary"><?php echo functions::draw_fonticon('fa-plus'); ?> <?php echo language::translate('title_create_primary_key', 'Create Primary Key'); ?></a>
          <button class="btn btn-default btn-" name="add_key" type="button" data-require-columns="true" data-kind="key"><?php echo functions::draw_fonticon('fa-plus'); ?> <?php echo language::translate('title_create_index_key', 'Create Index Key'); ?></a>
          <button class="btn btn-default btn-" name="add_unique_key" type="button" data-require-columns="true" data-kind="unique"><?php echo functions::draw_fonticon('fa-plus'); ?> <?php echo language::translate('title_create_unique_key', 'Create Unique Key'); ?></a>
        </td>
      </tfoot>
    </table>

    <div class="card-action">
      <?php echo functions::form_button('save', language::translate('title_save', 'Save'), 'submit', 'class="btn btn-success"', 'save'); ?>
      <?php echo !empty($table->previous['name']) ? functions::form_button('delete', language::translate('title_delete', 'Delete'), 'submit', 'formnovalidate class="btn btn-danger" onclick="if (!window.confirm(\''. language::translate('text_are_you_sure', 'Are you sure?') .'\')) return false;"', 'delete') : false; ?>
      <?php echo functions::form_button('cancel', language::translate('title_cancel', 'Cancel'), 'button', 'onclick="history.go(-1);"', 'cancel'); ?>
    </div>

  <?php echo functions::form_end(); ?>
</div>

<datalist id="default-options">
  <option value="NULL"></option>
  <option value="current_timestamp()"></option>
</datalist>

<script>
  $('table.columns').on('change', 'select[name$="\[type\]"]', function(){
    let $tr = $(this).closest('tr');
    let $type = $(this).find('option:selected');
    $tr.find(':input[name$="\[collation\]"]').prop('disabled', !$type.data('collation'));
    $tr.find(':input[name$="\[unsigned\]"]').prop('disabled', !$type.data('unsigned'));
    $tr.find(':input[name$="\[default\]"]').attr('placeholder', $tr.find(':input[name$="\[null\]"]').is('checked') ? 'NULL' : $type.data('default'));
    $tr.find(':input[name$="\[length\]"]').attr('placeholder', $type.data('length'));
  });

  $('table.columns').on('change', ':input[name$="\[null\]"]', function(){
    let $tr = $(this).closest('tr');
    let $type = $tr.find('select[name$="\[type\]"] option:selected');
    $tr.find(':input[name$="\[default\]"]').attr('placeholder', $(this).is(':checked') ? 'NULL' : $type.data('default'));
  });

  $('table.columns select[name$="\[type\]"]').trigger('change');

  var new_column_key_i = 0; while ($('columns[new_'+ new_column_key_i +']').length) new_column_key_i++;
  $('table.columns button[name="add_column"]').click(function(){
    $row = $(
      '<tr>' +
      '  <td><?php echo functions::escape_js(functions::form_checkbox('selected_columns[]', '1')); ?></td>' +
      '  <td></td>' +
      '  <td><?php echo functions::escape_js(functions::form_text_field('columns[new_column_key_i][name]', '')); ?></td>' +
      '  <td><?php echo functions::escape_js(functions::form_select_optgroup_field('columns[new_column_key_i][type]', $column_types, '')); ?></td>' +
      '  <td><?php echo functions::escape_js(functions::form_checkbox('columns[new_column_key_i][unsigned]', '1')); ?></td>' +
      '  <td><?php echo functions::escape_js(functions::form_text_field('columns[new_column_key_i][length]', '')); ?></td>' +
      '  <td><?php echo functions::escape_js(functions::form_checkbox('columns[new_column_key_i][null]', 'YES', '')); ?></td>' +
      '  <td><?php echo functions::escape_js(functions::form_text_field('columns[new_column_key_i][default]', '', 'list="default-options"')); ?></td>' +
      '  <td><?php echo functions::escape_js(functions::form_mysql_collations_list('columns[new_column_key_i][collation]', '')); ?></td>' +
      '  <td><?php echo functions::escape_js(functions::form_text_field('columns[new_column_key_i][comment]', '')); ?></td>' +
      '  <td class="grabable text-center"><?php echo functions::draw_fonticon('fa-arrows-v'); ?></td>' +
      '  <td class="text-end">' +
      '    <button class="btn btn-danger btn-sm" name="remove" value="true" type="button" title="<?php echo functions::escape_js(language::translate('title_remove', 'Remove')); ?>"><?php echo functions::escape_js(functions::draw_fonticon('fa-trash')); ?></button>' +
      '  </td>' +
      '</tr>'
    ).html(function(index,html){
      return html.replace(/new_column_key_i/, new_column_key_i++);
    });
    $('table.columns tbody').append($row);
    $('table.columns tbody tr:last select[name$="\[type\]"]').trigger('change');
  });

  $('table.columns').on('click', 'button[name="remove"]', function(){
    if (!window.confirm("<?php echo functions::escape_js(language::translate('text_are_you_sure', 'Are you sure?')); ?>")) return false;
    $(this).closest('tr').remove();
  });

  var new_index_key_i = 0; while ($('indexes[new_'+ new_index_key_i +']').length) new_index_key_i++;
  $('button[name="add_primary_key"], button[name="add_key"], button[name="add_unique_key"]').click(function(){
    var $row = $(
      '<tr>' +
      '  <td><?php echo functions::escape_js(functions::form_checkbox('selected_columns[]', '')); ?></td>' +
      '  <td>'+ prompt("What would you like to name this key?") +'</td>' +
      '  <td><?php echo functions::form_text_field('indexes[new_index_key_i][type]'); ?></td>' +
      '  <td>'+ $(this).data('kind') +'</td>' +
      '  <td><?php //echo implode(', ', $index['columns']); ?></td>' +
      '  <td><?php //echo $index['cardinality']; ?></td>' +
      '  <td><?php //echo $index['type']; ?></td>' +
      '  <td class="text-end"><button class="btn btn-danger btn-sm" name="remove" value="true" type="button" title="<?php echo functions::escape_js(language::translate('title_remove', 'Remove')); ?>"><?php echo functions::draw_fonticon('fa-trash'); ?></button></td>' +
      '</tr>'
    ).html(function(index,html){
      return html.replace(/new_index_key_i/, new_index_key_i++);
    });
    $('table.indexes tbody').append($row);
  });

  $('table.indexes').on('click', 'button[name="remove"]', function(){
    if (!window.confirm("<?php echo functions::escape_js(language::translate('text_are_you_sure', 'Are you sure?')); ?>")) return false;
    $(this).closest('tr').remove();
  });

  $('table.columns tr td:first-child :checkbox').change(function() {
    $('button[data-require-columns="true"]').prop('disabled', !$('table.columns tr td:first-child :checkbox:checked').length);
  }).first().trigger('change');
</script>
