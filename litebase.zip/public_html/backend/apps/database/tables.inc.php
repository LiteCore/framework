<?php

// Table rows
  $tables = [];
  foreach (reference::database(1)->tables as $table) {
    $app_config['menu'][] = [
      'title' => $table['name'],
      'doc' => 'data',
      'params' => ['table' => $table['name']],
    ];
  }

?>
<style>
.card-app table {
  /*font-family: Monospace;*/
}
.card-app table td:not([class="main"]) {
  white-space: nowrap;
}
.card-app table td input,
.card-app table td select {
  min-width: max-content;
}
.data-table td a {
  background: #e3ebf3;
  padding: 0.25em 1em;
  border-radius: var(--border-radius);
}
</style>

<div class="card card-app">
  <div class="card-header">
    <div class="card-title">
      <?php echo $app_icon; ?> <?php echo language::translate('title_database_tables', 'Database Tables'); ?>
    </div>
  </div>

  <div class="card-action">
    <ul class="list-inline">
      <li><a class="btn btn-default" href="<?php echo document::href_ilink(__APP__.'/edit_table'); ?>"><?php echo functions::draw_fonticon('fa-plus'); ?> <?php echo language::translate('title_create_new_table', 'Create New Table'); ?></a></li>
    </ul>
  </div>

    <table class="table table-striped table-hover table-sortable data-table">
      <thead>
        <tr>
          <th><?php echo functions::draw_fonticon('fa-check-square-o fa-fw', 'data-toggle="checkbox-toggle"'); ?></th>
          <th><?php echo language::translate('title_name', 'Name'); ?></th>
          <th><?php echo language::translate('title_rows', 'Rows'); ?></th>
          <th><?php echo language::translate('title_collation', 'Collation'); ?></th>
          <th><?php echo language::translate('title_engine', 'Engine'); ?></th>
          <th class="main"><?php echo language::translate('title_comment', 'Comment'); ?></th>
          <th></th>
        </tr>
      </thead>

      <tbody>
        <?php foreach (reference::database()->tables as $table) { ?>
        <tr>
          <td><?php echo functions::form_checkbox('tables[]', $table['name']); ?></td>
          <td><a class="link" href="<?php echo document::href_ilink(__APP__.'/table', ['name' => $table['name']]); ?>"><?php echo $table['name']; ?></a></td>
          <td class="text-center"><?php echo $table['rows']; ?></td>
          <td><?php echo $table['collation']; ?></td>
          <td><?php echo $table['engine']; ?></td>
          <td><?php echo $table['comment']; ?></td>
          <td class="text-end"><a class="btn btn-default btn-sm" href="<?php echo document::href_ilink(__APP__.'/edit_table', ['name' => $table['name']]); ?>" title="<?php echo language::translate('title_edit', 'Edit'); ?>"><?php echo functions::draw_fonticon('fa-pencil'); ?></a></td>
        </tr>
        <?php } ?>
      </tbody>

      <tfoot>
        <td colspan="10">
          <?php echo language::translate('title_tables', 'Tables'); ?>: <?php echo count(reference::database(1)->tables); ?>
        </td>
      </tfoot>
    </table>

    <div class="card-body">
      <fieldset id="actions">
        <legend><?php echo language::translate('text_with_selected', 'With selected'); ?></legend>

        <ul class="list-inline">
          <li><?php echo functions::form_button('check', language::translate('title_check', 'Check'), 'submit', '', 'fa-stethoscope'); ?></li>
          <li><?php echo functions::form_button('repair', language::translate('title_repair', 'Repair'), 'submit', '', 'fa-medkit'); ?></li>
          <li><?php echo functions::form_button('truncate', language::translate('title_truncate', 'Truncate'), 'submit', 'formnovalidate class="btn btn-danger" onclick="if (!confirm(\''. language::translate('text_are_you_sure', 'Are you sure?') .'\')) return false;"', 'delete'); ?></li>
          <li><?php echo functions::form_button('delete', language::translate('title_delete', 'Delete'), 'submit', 'formnovalidate class="btn btn-danger" onclick="if (!confirm(\''. language::translate('text_are_you_sure', 'Are you sure?') .'\')) return false;"', 'delete'); ?></li>
        </ul>
      </fieldset>
    </div>
</div>

<script>
  $('.data-table :checkbox').change(function() {
    $('#actions').prop('disabled', !$('.data-table :checked').length);
  }).first().trigger('change');
</script>
