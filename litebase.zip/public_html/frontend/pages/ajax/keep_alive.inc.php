<?php

  class_exists('session', true);
  return;
