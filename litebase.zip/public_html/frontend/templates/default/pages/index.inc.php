<div id="content">
  {{notices}}

  Hello world

</div>
