<div id="sidebar">
  <?php include 'app://frontend/boxes/box_information_links.inc.php'; ?>
</div>

<div id="content">
  {{breadcrumbs}}
  {{notices}}

  <section id="box-information" class="box">
    {{content}}
  </section>

</div>